//
//  PatientInfoViewController.swift
//  Algomatrix2018
//
//  Created by Saif Khan on 3/8/18.
//  Copyright © 2018 Saif Khan. All rights reserved.
//

import UIKit
import os.log

class PatientInfoViewController: UIViewController, UITextFieldDelegate, UITextViewDelegate {
    
    //Mark: Properties
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var ageTextField: UITextField!
    @IBOutlet weak var DOBTextField: UITextField!
    @IBOutlet weak var commentTextView: UITextView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var DOBLabel: UILabel!
    @IBOutlet weak var commentLabel: UILabel!
    @IBOutlet weak var saveButton: UIBarButtonItem!
    @IBOutlet weak var InfoToolBar: UIToolbar!
    
    /*
     This value is either passed by `PatientTableViewController` in `prepare(for:sender:)`
     or constructed as part of adding a new meal.
     */
    var patient: Patient?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nameTextField.delegate = self
        ageTextField.delegate = self
        DOBTextField.delegate = self
        commentTextView.delegate = self
        
        // Set up views if editing an existing Meal.
        if let patient = patient {
            navigationItem.title = patient.name
            nameTextField.text = patient.name
            ageTextField.text = patient.age
            DOBTextField.text = patient.birth
            commentTextView.text = patient.comment
        }
        
        // Enable the Save button only if the text field has a valid Meal name.
        updateSaveButtonState()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: UITextFieldDelegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        updateSaveButtonState()
        
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        // Disable the Save button while editing.
        saveButton.isEnabled = false
    }
    
    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        super.prepare(for: segue, sender: sender)
        
        // Configure the destination view controller only when the save button is pressed.
        guard let button = sender as? UIBarButtonItem, button === saveButton else {
            os_log("The save button was not pressed, cancelling", log: OSLog.default, type: .debug)
            return
        }
        
        let name = nameTextField.text ?? ""
        let age = ageTextField.text ?? ""
        let DOB = DOBTextField.text ?? ""
        let comment = commentTextView.text ?? ""
        
        // Set the meal to be passed to MealTableViewController after the unwind segue.
        patient = Patient(name: name, age: age, birth: DOB, comment: comment)
    }
    
    //MARK: Private Methods
    private func updateSaveButtonState() {
        // Disable the Save button if the text field is empty.
        let text = nameTextField.text ?? ""
        saveButton.isEnabled = !text.isEmpty
    }
}

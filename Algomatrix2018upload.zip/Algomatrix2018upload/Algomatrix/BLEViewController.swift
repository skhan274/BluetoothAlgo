//
//  BLEViewController.swift
//  Algomatrix
//
//  Created by Saif Khan on 4/23/18.
//  Copyright © 2018 Saif Khan. All rights reserved.
//
import UIKit

class BLEViewController: UIViewController {
    
    var bleManager: BLEManagable?
    
    @IBOutlet weak var temperatureLabel: UILabel!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        bleManager?.addDelegate(self)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        bleManager?.removeDelegate(self)
    }
}

// MARK: BLEManagerDelegate
extension BLEViewController: BLEManagerDelegate {
    
    func bleManagerDidConnect(_ manager: BLEManagable) {
        self.temperatureLabel.textColor = UIColor.black
    }
    func bleManagerDidDisconnect(_ manager: BLEManagable) {
        self.temperatureLabel.textColor = UIColor.red
    }
    func bleManager(_ manager: BLEManagable, receivedDataString dataString: String) {
        self.temperatureLabel.text = dataString + "℃"
    }
}

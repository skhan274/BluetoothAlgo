//
//  PatientViewController.swift
//  Algomatrix2018
//
//  Created by Saif Khan on 2/6/18.
//  Copyright © 2018 Saif Khan. All rights reserved.
//

import UIKit
import os.log

class PatientViewController: UIViewController, UITextFieldDelegate, UITextViewDelegate {

    //MARK: Properties
    @IBOutlet weak var patientnameTextField: UITextField!
    @IBOutlet weak var patientageTextField: UITextField!
    @IBOutlet weak var patientbirthTextField: UITextField!
    @IBOutlet weak var patientNameLabel: UILabel!
    @IBOutlet weak var patientAgeLabel: UILabel!
    @IBOutlet weak var patientBirthLabel: UILabel!
    @IBOutlet weak var saveButton: UIBarButtonItem!
    @IBOutlet weak var patientCommentLabel: UILabel!
    @IBOutlet weak var patientcommentTextField: UITextView!
    
    /*
     This value is either passed by `PatientTableViewController` in `prepare(for:sender:)`
     or constructed as part of adding a new meal.
     */
    var patient: Patient?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Handle the text field’s user input through delegate callbacks.
        patientnameTextField.delegate = self
        patientageTextField.delegate = self
        patientbirthTextField.delegate = self
        patientcommentTextField.delegate = self
        
        // Enable the Save button only if the text field has a valid Meal name.
        updateSaveButtonState()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: UITextFieldDelegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        updateSaveButtonState()
        
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        // Disable the Save button while editing.
        saveButton.isEnabled = false
    }
    
    //MARK: Navigation
    @IBAction func cancel(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
    // This method lets you configure a view controller before it's presented.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
            super.prepare(for: segue, sender: sender)
        
        // Configure the destination view controller only when the save button is pressed.
        guard let button = sender as? UIBarButtonItem, button === saveButton else {
            os_log("The save button was not pressed, cancelling", log: OSLog.default, type: .debug)
            return
        }
        
        let name = patientnameTextField.text ?? ""
        let age = patientageTextField.text ?? ""
        let birth = patientbirthTextField.text ?? ""
        let comment = patientcommentTextField.text ?? ""
        
        // Set the meal to be passed to MealTableViewController after the unwind segue.
        patient = Patient(name: name, age: age, birth: birth, comment: comment)
    }
    
    //MARK: Action
    
    //MARK: Private Methods
    private func updateSaveButtonState() {
        // Disable the Save button if the text field is empty.
        let text = patientnameTextField.text ?? ""
        saveButton.isEnabled = !text.isEmpty
    }
    
}



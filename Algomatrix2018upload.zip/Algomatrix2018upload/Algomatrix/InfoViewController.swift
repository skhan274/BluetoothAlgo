//
//  InfoViewController.swift
//  Algomatrix2018
//
//  Created by Saif Khan on 3/6/18.
//  Copyright © 2018 Saif Khan. All rights reserved.
//

import UIKit
import os.log
class InfoViewController: UIViewController, UITextFieldDelegate {

    //MARK: Properties
    
    @IBOutlet weak var patientNameLabel: UILabel!
    @IBOutlet weak var patientAgeLabel: UILabel!
    @IBOutlet weak var patientBirthLabel: UILabel!
    @IBOutlet weak var patientnameTextField: UITextField!
    @IBOutlet weak var patientageTextField: UITextField!
    @IBOutlet weak var patientbirthTextField: UITextField!
    @IBOutlet weak var MuscleTextField: UITextField!
    @IBOutlet weak var dropDownWheel: UIPickerView!
    @IBOutlet weak var saveButton: UIBarButtonItem!
    @IBOutlet weak var patientMuscleLabel: UILabel!
    
    /*
     This value is either passed by `PatientTableViewController` in `prepare(for:sender:)`
     or constructed as part of adding a new meal.
     */
    var pickerlist = ["R Bicep","L Bicep","R Tricep","L Tricep","R Forearm","L Forearm","R Deltoid","L Deltoid","R Pectoral","L Pectoral","R Trapezoid","L Trapezoid","R Latissimus Dorsi","L Latissimus Dorsi","R Gluteus Maximus","L Gluteus Maximus","R Quadricep","L Quadricep","R Gastrocnemius","L Gastrocnemius"]
    var patient: Patient?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Handle the text field’s user input through delegate callbacks.
        patientnameTextField.delegate = self
        patientageTextField.delegate = self
        patientbirthTextField.delegate = self
        
        // Enable the Save button only if the text field has a valid Meal name.
        updateSaveButtonState()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView,numberOfRowsInComponent component: Int) -> Int {
        return pickerlist.count
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String! {
        self.view.endEditing(true)
        return pickerlist[row]
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.MuscleTextField.text = self.pickerlist[row]
        self.dropDownWheel.isHidden = true
    }
    
    //MARK: UITextFieldDelegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        updateSaveButtonState()
        navigationItem.title = textField.text
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        // Disable the Save button while editing.
        saveButton.isEnabled = false
        
        if textField == self.MuscleTextField {
            self.dropDownWheel.isHidden = false
        }
    }
    
    //MARK: Navigation
   // @IBAction func cancel(_ sender: UIBarButtonItem) {
       // dismiss(animated: true, completion: nil)
   // }
    
    // This method lets you configure a view controller before it's presented.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        super.prepare(for: segue, sender: sender)
        
        // Configure the destination view controller only when the save button is pressed.
        guard let button = sender as? UIBarButtonItem, button === saveButton else {
            os_log("The save button was not pressed, cancelling", log: OSLog.default, type: .debug)
            return
        }
        
        let name = patientnameTextField.text ?? ""
        let age = patientageTextField.text ?? ""
        let birth = patientbirthTextField.text ?? ""
        
        // Set the meal to be passed to MealTableViewController after the unwind segue.
        patient = Patient(name: name, age: age, birth: birth)
    }
    
    //MARK: Action
    
    //MARK: Private Methods
    private func updateSaveButtonState() {
        // Disable the Save button if the text field is empty.
        let text = patientnameTextField.text ?? ""
        saveButton.isEnabled = !text.isEmpty
    }
    
}





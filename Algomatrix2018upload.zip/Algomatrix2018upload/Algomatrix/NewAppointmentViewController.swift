//
//  NewAppointmentViewController.swift
//  Algomatrix2018
//
//  Created by Saif Khan on 3/13/18.
//  Copyright © 2018 Saif Khan. All rights reserved.
//

import UIKit
import os.log

class NewAppointmentViewController: UIViewController, UITextViewDelegate, UITextFieldDelegate {
    //Mark: Properties
    @IBOutlet weak var appointmentName: UITextField!
    @IBOutlet weak var appointmentDate: UITextField!
    @IBOutlet weak var appointmentMuscle: UITextView!
    @IBOutlet weak var appointmentNameLabel: UILabel!
    @IBOutlet weak var appointmentDateLabel: UILabel!
    @IBOutlet weak var appointmentMuscleLabel: UILabel!
    @IBOutlet weak var newappointmentsaveButton: UIBarButtonItem!
    
    /*
     This value is either passed by `MealTableViewController` in `prepare(for:sender:)`
     or constructed as part of adding a new meal.
     */
    var appointment: Appointment?

    override func viewDidLoad() {
        super.viewDidLoad()

        appointmentName.delegate = self
        appointmentDate.delegate = self
        appointmentMuscle.delegate = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
    
    //MARK: Navigation
    @IBAction func cancelAppointment(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
    
    // This method lets you configure a view controller before it's presented.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        // Configure the destination view controller only when the save button is pressed.
        guard let button = sender as? UIBarButtonItem, button === newappointmentsaveButton else {
            os_log("The save button was not pressed, cancelling", log: OSLog.default, type: .debug)
            return
        }
        let appointmentname = appointmentName.text ?? ""
        let appointmentdate = appointmentDate.text ?? ""
        let appointmentmuscle = appointmentMuscle.text ?? ""
        
        appointment = Appointment(appointmentname: appointmentname, appointmentdate: appointmentdate, appointmentmuscle: appointmentmuscle)
    }
    
    

}

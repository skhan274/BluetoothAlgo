//
//  AppointmentsTableViewController.swift
//  Algomatrix2018
//
//  Created by Saif Khan on 3/13/18.
//  Copyright © 2018 Saif Khan. All rights reserved.
//

import UIKit
import os.log

class AppointmentsTableViewController: UITableViewController {
    
    //Mark: Properties
    var appointments = [Appointment]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Load any saved meals, otherwise load sample data.
        if let savedAppointments = loadAppointments() {
            appointments += savedAppointments
        }
        else {
            //Load the sample data.
            loadSampleAppointments()
        }

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return appointments.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // Table view cells are reused and should be dequeued using a cell identifier.
        let cellIdentifier = "AppointmentTableViewCell"
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? AppointmentTableViewCell else {
            fatalError("The dequeued cell is not an instance of AppointmentTableViewCell.")
        }

        // Fetches the appropriate meal for the data source layout.
        let appointment = appointments[indexPath.row]
        
        cell.appointmentLabel.text = appointment.appointmentname

        return cell
    }
 

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            appointments.remove(at: indexPath.row)
            saveAppointments()
            tableView.deleteRows(at: [indexPath], with: .automatic)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }
    
    // MARK: - Navigation
    //MARK: Navigation
    
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        switch(segue.identifier ?? "") {
        case "AddAppointment":
            os_log("Adding a new appointment.", log: OSLog.default, type: .debug)
            
        case "AppointmentInfo":
            guard let appointmentDetailViewController = segue.destination as? AppointmentInfoViewController else {
                fatalError("Unexpected destination: \(segue.destination)")
            }
            
            guard let selectedAppointmentCell = sender as? AppointmentTableViewCell else {
                fatalError("Unexpected sender: \(sender)")
            }
            
            guard let indexPath = tableView.indexPath(for: selectedAppointmentCell) else {
                fatalError("The selected cell is not being displayed by the table")
            }
            
            let selectedAppointment = appointments[indexPath.row]
            appointmentDetailViewController.appointment = selectedAppointment
            
        default:
            fatalError("Unexpected Segue Identifier; \(segue.identifier)")
        }
    }
    

    //MARK: Private Methods
    
    private func loadSampleAppointments() {
        guard let appointment1 = Appointment(appointmentname: "Appointment 1", appointmentdate: "03/15/2018", appointmentmuscle: "Sample Muscle") else {
            fatalError("Unable to instantiate meal1")
        }
        appointments += [appointment1]
    }
    
    private func saveAppointments() {
        let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(appointments, toFile: Appointment.ArchiveURL.path)
        if isSuccessfulSave {
            os_log("Appointments successfully saved.", log: OSLog.default, type: .debug)
        } else {
            os_log("Failed to save appointments...", log: OSLog.default, type: .error)
        }
    }
    
    //MARK: Actions
    @IBAction func unwindToAppointmentList(sender: UIStoryboardSegue) {
        if let sourceViewController = sender.source as? NewAppointmentViewController, let appointment = sourceViewController.appointment {
            // Add a new meal.
            let newIndexPath = IndexPath(row: appointments.count, section: 0)
            appointments.append(appointment)
            tableView.insertRows(at: [newIndexPath], with: .automatic)
            // Save the patients.
            saveAppointments()
        }
        
        if let sourceViewController = sender.source as? AppointmentInfoViewController, let appointment = sourceViewController.appointment {
            if let selectedIndexPath = tableView.indexPathForSelectedRow {
                // Update an existing meal.
                appointments[selectedIndexPath.row] = appointment
                tableView.reloadRows(at: [selectedIndexPath], with: .none)
            }
            // Save the patients.
            saveAppointments()
        }
    }
    private func loadAppointments() -> [Appointment]?  {
        return NSKeyedUnarchiver.unarchiveObject(withFile: Appointment.ArchiveURL.path) as? [Appointment]
    
    }
}
